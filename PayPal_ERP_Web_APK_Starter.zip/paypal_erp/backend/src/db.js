const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, "paypal-erp.db"));
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  login_id TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  department TEXT NOT NULL,
  role TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_code TEXT UNIQUE NOT NULL,
  client_user_id INTEGER,
  project_name TEXT NOT NULL,
  description TEXT,
  location TEXT,
  status TEXT NOT NULL DEFAULT 'SETUP_SUBMITTED',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(client_user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS installations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  installation_code TEXT UNIQUE NOT NULL,
  project_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  site_contact TEXT,
  contact_number TEXT,
  location TEXT,
  start_date TEXT,
  expected_completion_date TEXT,
  actual_completion_date TEXT,
  assigned_user_id INTEGER,
  status TEXT NOT NULL DEFAULT 'ASSIGNED',
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(project_id) REFERENCES projects(id),
  FOREIGN KEY(assigned_user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS installation_tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  installation_id INTEGER NOT NULL,
  task_name TEXT NOT NULL,
  description TEXT,
  start_date TEXT,
  target_date TEXT,
  completion_date TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  remarks TEXT,
  FOREIGN KEY(installation_id) REFERENCES installations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS site_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  installation_id INTEGER NOT NULL,
  filename TEXT NOT NULL,
  original_name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(installation_id) REFERENCES installations(id) ON DELETE CASCADE
);
`);

function seedOwner() {
  const ownerEmail = process.env.OWNER_EMAIL || "owner@paypal-erp.local";
  const ownerPassword = process.env.OWNER_PASSWORD || "Owner@12345";
  const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(ownerEmail);
  if (!exists) {
    const hash = bcrypt.hashSync(ownerPassword, 12);
    db.prepare(`
      INSERT INTO users (login_id,email,password_hash,name,department,role)
      VALUES (?,?,?,?,?,?)
    `).run("PAY-OWNER-001", ownerEmail, hash, "System Owner", "ADMIN", "OWNER");
    console.log("Seeded owner:", ownerEmail);
  }
}
seedOwner();

module.exports = db;
