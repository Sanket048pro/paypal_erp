import React, {useEffect, useState} from "react";
import {
  SafeAreaView, View, Text, TextInput, Pressable, ScrollView,
  StyleSheet, Alert, Image
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import {api, API_URL} from "./src/api";

function Button({title,onPress}) {
  return <Pressable style={styles.button} onPress={onPress}><Text style={styles.buttonText}>{title}</Text></Pressable>
}

function Login({onLogin}) {
  const [loginId,setLoginId]=useState("PAY-OWNER-001");
  const [password,setPassword]=useState("Owner@12345");
  async function submit(){
    try {
      const d=await api("/auth/login",{method:"POST",body:JSON.stringify({loginId,password})});
      onLogin(d);
    } catch(e){Alert.alert("Login error",e.message)}
  }
  return <SafeAreaView style={styles.screen}><View style={styles.loginBox}>
    <Text style={styles.logo}>PAYPAL ERP</Text>
    <TextInput style={styles.input} value={loginId} onChangeText={setLoginId} placeholder="Login ID" placeholderTextColor="#777"/>
    <TextInput style={styles.input} value={password} onChangeText={setPassword} secureTextEntry placeholder="Password" placeholderTextColor="#777"/>
    <Button title="LOGIN" onPress={submit}/>
  </View></SafeAreaView>
}

function Owner({token}) {
  const [form,setForm]=useState({name:"",email:"",department:"ENGINEERING_TECHNICAL",role:"ENGINEER"});
  const [result,setResult]=useState(null);
  async function create(){
    try {
      const d=await api("/users",{method:"POST",body:JSON.stringify(form)},token);
      setResult(d);
      setForm({...form,name:"",email:""});
    } catch(e){Alert.alert("Error",e.message)}
  }
  return <View><Text style={styles.title}>Owner / Admin</Text>
    <TextInput style={styles.input} placeholder="Employee name" placeholderTextColor="#777" value={form.name} onChangeText={name=>setForm({...form,name})}/>
    <TextInput style={styles.input} placeholder="Email" placeholderTextColor="#777" value={form.email} onChangeText={email=>setForm({...form,email})}/>
    <TextInput style={styles.input} placeholder="Department" placeholderTextColor="#777" value={form.department} onChangeText={department=>setForm({...form,department})}/>
    <TextInput style={styles.input} placeholder="Role" placeholderTextColor="#777" value={form.role} onChangeText={role=>setForm({...form,role})}/>
    <Button title="CREATE LOGIN" onPress={create}/>
    {result && <View style={styles.card}><Text style={styles.text}>Login ID: {result.loginId}</Text><Text style={styles.text}>Temporary Password: {result.temporaryPassword}</Text></View>}
  </View>
}

function Engineer({token}) {
  const [installations,setInstallations]=useState([]);
  const [selected,setSelected]=useState(null);
  const [photos,setPhotos]=useState([]);

  async function load(){try{setInstallations(await api("/installations",{},token))}catch(e){Alert.alert("Error",e.message)}}
  useEffect(()=>{load()},[]);

  async function status(status){
    try{await api(`/installations/${selected.id}`,{method:"PATCH",body:JSON.stringify({status})},token);load();setSelected({...selected,status})}
    catch(e){Alert.alert("Error",e.message)}
  }

  async function takePhotos(){
    const permission=await ImagePicker.requestMediaLibraryPermissionsAsync();
    if(!permission.granted){Alert.alert("Permission required","Allow photo access.");return}
    const result=await ImagePicker.launchImageLibraryAsync({mediaTypes:["images"],allowsMultipleSelection:true,quality:.8});
    if(result.canceled)return;
    const fd=new FormData();
    result.assets.forEach((asset,i)=>{
      fd.append("photos",{uri:asset.uri,name:`site-${Date.now()}-${i}.jpg`,type:"image/jpeg"});
    });
    try{
      const d=await api(`/installations/${selected.id}/photos`,{method:"POST",body:fd},token);
      setPhotos(d.files);
      Alert.alert("Uploaded","Site photos uploaded.");
    }catch(e){Alert.alert("Upload error",e.message)}
  }

  return <View><Text style={styles.title}>Engineering & Technical</Text>
    {installations.map(i=><Pressable style={styles.card} key={i.id} onPress={()=>setSelected(i)}>
      <Text style={styles.cardTitle}>{i.installation_code}</Text>
      <Text style={styles.text}>{i.title}</Text>
      <Text style={styles.text}>Status: {i.status}</Text>
    </Pressable>)}
    {selected && <View style={styles.card}>
      <Text style={styles.cardTitle}>{selected.title}</Text>
      <Text style={styles.text}>{selected.location}</Text>
      <View style={styles.row}>
        <Button title="IN PROGRESS" onPress={()=>status("IN_PROGRESS")}/>
        <Button title="COMPLETED" onPress={()=>status("COMPLETED")}/>
      </View>
      <Button title="UPLOAD SITE PHOTOS" onPress={takePhotos}/>
      {photos.map(p=><Image key={p.url} source={{uri:API_URL.replace("/api","")+p.url}} style={styles.photo}/>)}
    </View>}
  </View>
}

function Generic({user}) {
  return <View><Text style={styles.title}>{user.department}</Text><View style={styles.card}><Text style={styles.text}>Role: {user.role}</Text><Text style={styles.text}>This role is authenticated and isolated. Detailed department screens can be added from the finalized workflow.</Text></View></View>
}

export default function App(){
  const [session,setSession]=useState(null);
  if(!session)return <Login onLogin={setSession}/>;
  const {user,token}=session;
  return <SafeAreaView style={styles.screen}><ScrollView contentContainerStyle={styles.container}>
    <Text style={styles.header}>PAYPAL ERP</Text>
    <Text style={styles.text}>{user.name} · {user.department}</Text>
    {user.role==="OWNER"?<Owner token={token}/>:user.role==="ENGINEER"?<Engineer token={token}/>:<Generic user={user}/>}
  </ScrollView></SafeAreaView>
}

const styles=StyleSheet.create({
  screen:{flex:1,backgroundColor:"#090b10"},
  container:{padding:18,paddingBottom:50},
  loginBox:{margin:"auto",padding:24},
  logo:{fontSize:30,fontWeight:"800",color:"#fff",marginBottom:25},
  header:{fontSize:22,fontWeight:"800",color:"#fff"},
  title:{fontSize:24,fontWeight:"800",color:"#fff",marginTop:22,marginBottom:12},
  text:{color:"#d4d7de",fontSize:15,marginBottom:6},
  input:{backgroundColor:"#151922",borderColor:"#303542",borderWidth:1,borderRadius:10,color:"#fff",padding:12,marginBottom:10},
  button:{backgroundColor:"#e11d48",padding:12,borderRadius:10,marginVertical:6,alignItems:"center"},
  buttonText:{color:"#fff",fontWeight:"800"},
  card:{backgroundColor:"#121620",borderColor:"#292e3a",borderWidth:1,borderRadius:14,padding:16,marginVertical:8},
  cardTitle:{color:"#fff",fontWeight:"800",fontSize:17,marginBottom:7},
  row:{flexDirection:"row",gap:8},
  photo:{width:"100%",height:200,borderRadius:10,marginTop:10}
});
