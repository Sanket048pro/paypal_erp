import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const API = "http://localhost:4000/api";

async function request(path, options = {}) {
  const token = localStorage.getItem("token");
  const headers = { ...(options.headers || {}) };
  if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(API + path, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}

function Login({ onLogin }) {
  const [loginId, setLoginId] = useState("PAY-OWNER-001");
  const [password, setPassword] = useState("Owner@12345");
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setError("");
    try {
      const data = await request("/auth/login", {
        method: "POST",
        body: JSON.stringify({ loginId, password })
      });
      localStorage.setItem("token", data.token);
      onLogin(data.user);
    } catch (e) { setError(e.message); }
  }

  return <div className="login">
    <form className="card login-card" onSubmit={submit}>
      <h1>PAYPAL ERP</h1>
      <p>Web ERP Login</p>
      <input value={loginId} onChange={e=>setLoginId(e.target.value)} placeholder="Login ID" />
      <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password" />
      <button>Login</button>
      {error && <div className="error">{error}</div>}
    </form>
  </div>;
}

function OwnerDashboard() {
  const [users,setUsers] = useState([]);
  const [form,setForm] = useState({name:"",email:"",department:"ENGINEERING_TECHNICAL",role:"ENGINEER"});
  const [created,setCreated] = useState(null);

  async function load(){ setUsers(await request("/users")); }
  useEffect(()=>{load()},[]);

  async function create(e){
    e.preventDefault();
    const d=await request("/users",{method:"POST",body:JSON.stringify(form)});
    setCreated(d);
    setForm({...form,name:"",email:""});
    load();
  }

  return <section>
    <h2>Owner / Admin Dashboard</h2>
    <div className="grid">
      <form className="card" onSubmit={create}>
        <h3>Create Employee Account</h3>
        <input placeholder="Employee name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
        <input placeholder="Email (optional)" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
        <select value={form.department} onChange={e=>setForm({...form,department:e.target.value})}>
          <option value="SALES_MARKETING">Sales & Marketing</option>
          <option value="PROJECT_DESIGN">Project Design</option>
          <option value="ESTIMATION">Estimation</option>
          <option value="PURCHASE_INVENTORY">Purchase & Inventory</option>
          <option value="ACCOUNTS_BILLING">Accounts & Billing</option>
          <option value="ENGINEERING_TECHNICAL">Engineering & Technical</option>
        </select>
        <select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
          <option value="SALES">Sales</option>
          <option value="DESIGNER">Designer</option>
          <option value="ESTIMATOR">Estimator</option>
          <option value="PURCHASE">Purchase</option>
          <option value="ACCOUNTS">Accounts</option>
          <option value="ENGINEER">Engineer</option>
        </select>
        <button>Create Login</button>
        {created && <div className="success">
          Login ID: <b>{created.loginId}</b><br/>
          Temporary password: <b>{created.temporaryPassword}</b>
        </div>}
      </form>
      <div className="card">
        <h3>Users</h3>
        <table><thead><tr><th>Login</th><th>Name</th><th>Department</th><th>Status</th></tr></thead>
        <tbody>{users.map(u=><tr key={u.id}><td>{u.login_id}</td><td>{u.name}</td><td>{u.department}</td><td>{u.status}</td></tr>)}</tbody></table>
      </div>
    </div>
  </section>
}

function ClientDashboard() {
  const [projects,setProjects]=useState([]);
  const [form,setForm]=useState({projectName:"",description:"",location:""});
  async function load(){setProjects(await request("/projects"))}
  useEffect(()=>{load()},[]);
  async function submit(e){
    e.preventDefault();
    await request("/projects/setup",{method:"POST",body:JSON.stringify(form)});
    setForm({projectName:"",description:"",location:""});
    load();
  }
  return <section><h2>Client Dashboard</h2>
    <div className="grid">
      <form className="card" onSubmit={submit}>
        <h3>Project Setup Form</h3>
        <input placeholder="Project name" value={form.projectName} onChange={e=>setForm({...form,projectName:e.target.value})}/>
        <input placeholder="Project location" value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/>
        <textarea placeholder="Project description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
        <button>Submit Project Setup</button>
      </form>
      <div className="card"><h3>My Projects / Progress</h3>
        {projects.map(p=><div className="item" key={p.id}><b>{p.project_code}</b><br/>{p.project_name}<br/><span>{p.status}</span></div>)}
      </div>
    </div>
  </section>
}

function EngineerDashboard() {
  const [projects,setProjects]=useState([]);
  const [installations,setInstallations]=useState([]);
  const [form,setForm]=useState({projectId:"",title:"",location:"",siteContact:"",contactNumber:"",startDate:"",expectedCompletionDate:"",notes:""});
  const [selected,setSelected]=useState(null);
  const [task,setTask]=useState({taskName:"",description:"",targetDate:""});

  async function load(){setProjects(await request("/projects"));setInstallations(await request("/installations"))}
  useEffect(()=>{load()},[]);

  async function create(e){
    e.preventDefault();
    await request("/installations",{method:"POST",body:JSON.stringify(form)});
    setForm({...form,title:"",notes:""});
    load();
  }

  async function addTask(e){
    e.preventDefault();
    await request(`/installations/${selected.id}/tasks`,{method:"POST",body:JSON.stringify(task)});
    setTask({taskName:"",description:"",targetDate:""});
    alert("Task added");
  }

  async function updateStatus(status){
    await request(`/installations/${selected.id}`,{method:"PATCH",body:JSON.stringify({status})});
    load();
  }

  async function upload(e){
    const fd=new FormData();
    [...e.target.files].forEach(f=>fd.append("photos",f));
    await request(`/installations/${selected.id}/photos`,{method:"POST",body:fd});
    alert("Photos uploaded");
  }

  return <section><h2>Engineering & Technical Dashboard</h2>
    <div className="grid">
      <form className="card" onSubmit={create}>
        <h3>Create Installation</h3>
        <select value={form.projectId} onChange={e=>setForm({...form,projectId:e.target.value})}>
          <option value="">Select project</option>
          {projects.map(p=><option key={p.id} value={p.id}>{p.project_code} - {p.project_name}</option>)}
        </select>
        <input placeholder="Installation title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
        <input placeholder="Site location" value={form.location} onChange={e=>setForm({...form,location:e.target.value})}/>
        <input placeholder="Site contact" value={form.siteContact} onChange={e=>setForm({...form,siteContact:e.target.value})}/>
        <input placeholder="Contact number" value={form.contactNumber} onChange={e=>setForm({...form,contactNumber:e.target.value})}/>
        <input type="date" value={form.startDate} onChange={e=>setForm({...form,startDate:e.target.value})}/>
        <input type="date" value={form.expectedCompletionDate} onChange={e=>setForm({...form,expectedCompletionDate:e.target.value})}/>
        <textarea placeholder="Notes" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/>
        <button>Create Installation</button>
      </form>

      <div className="card">
        <h3>Installations</h3>
        {installations.map(i=><button className="list-button" key={i.id} onClick={()=>setSelected(i)}>
          {i.installation_code} — {i.title} — {i.status}
        </button>)}
      </div>
    </div>

    {selected && <div className="card">
      <h3>{selected.installation_code} — {selected.title}</h3>
      <p>Project: {selected.project_code} — {selected.project_name}</p>
      <div className="actions">
        {["ASSIGNED","SCHEDULED","IN_PROGRESS","INSPECTION","COMPLETED","ON_HOLD"].map(s=>
          <button key={s} onClick={()=>updateStatus(s)}>{s}</button>
        )}
      </div>
      <hr/>
      <form onSubmit={addTask} className="inline-form">
        <input placeholder="Task name" value={task.taskName} onChange={e=>setTask({...task,taskName:e.target.value})}/>
        <input placeholder="Description" value={task.description} onChange={e=>setTask({...task,description:e.target.value})}/>
        <input type="date" value={task.targetDate} onChange={e=>setTask({...task,targetDate:e.target.value})}/>
        <button>Add Task</button>
      </form>
      <label className="upload">Upload site photos
        <input type="file" multiple accept="image/*" onChange={upload}/>
      </label>
    </div>}
  </section>
}

function GenericDashboard({user}) {
  const titles = {
    SALES:"Sales & Marketing Dashboard",
    DESIGNER:"Project Design Dashboard",
    ESTIMATOR:"Estimation Dashboard",
    PURCHASE:"Purchase & Inventory Dashboard",
    ACCOUNTS:"Accounts & Billing Dashboard"
  };
  return <section><h2>{titles[user.role] || `${user.department} Dashboard`}</h2>
    <div className="card"><h3>Department Workspace</h3>
      <p>Login and role access are active. This dashboard is the controlled workspace for <b>{user.department}</b>.</p>
      <p>The detailed fields for this department should be added from the exact workflow you provide.</p>
    </div>
  </section>
}

function App(){
  const [user,setUser]=useState(null);
  useEffect(()=>{
    if(localStorage.getItem("token")) request("/me").then(x=>setUser(x.user)).catch(()=>localStorage.removeItem("token"));
  },[]);
  if(!user) return <Login onLogin={setUser}/>;

  function logout(){localStorage.removeItem("token");setUser(null)}
  let page;
  if(user.role==="OWNER") page=<OwnerDashboard/>;
  else if(user.role==="CLIENT") page=<ClientDashboard/>;
  else if(user.role==="ENGINEER") page=<EngineerDashboard/>;
  else page=<GenericDashboard user={user}/>;

  return <div className="app">
    <header><div><b>PAYPAL ERP</b><small>{user.name} · {user.department}</small></div><button onClick={logout}>Logout</button></header>
    <main>{page}</main>
  </div>
}

createRoot(document.getElementById("root")).render(<App/>);
