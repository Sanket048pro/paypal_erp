const jwt = require("jsonwebtoken");

const secret = process.env.JWT_SECRET || "dev-only-change-me";

function signUser(user) {
  return jwt.sign(
    {
      id: user.id,
      loginId: user.login_id,
      name: user.name,
      department: user.department,
      role: user.role
    },
    secret,
    { expiresIn: "8h" }
  );
}

function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: "Login required" });

  try {
    req.user = jwt.verify(token, secret);
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired login token" });
  }
}

function allow(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Access denied for this role" });
    }
    next();
  };
}

module.exports = { signUser, auth, allow };
