require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const db = require("./db");
const { signUser, auth, allow } = require("./auth");

const app = express();
const PORT = Number(process.env.PORT || 4000);

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const uploadDir = path.join(__dirname, "..", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
app.use("/uploads", express.static(uploadDir));

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, crypto.randomUUID() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }
});

const departments = [
  "ADMIN",
  "SALES_MARKETING",
  "PROJECT_DESIGN",
  "ESTIMATION",
  "PURCHASE_INVENTORY",
  "ACCOUNTS_BILLING",
  "ENGINEERING_TECHNICAL",
  "CLIENT"
];

const roles = [
  "OWNER",
  "SALES",
  "DESIGNER",
  "ESTIMATOR",
  "PURCHASE",
  "ACCOUNTS",
  "ENGINEER",
  "CLIENT"
];

function makeLoginId(department) {
  const prefix = {
    ADMIN: "PAY-ADM",
    SALES_MARKETING: "PAY-SAL",
    PROJECT_DESIGN: "PAY-DES",
    ESTIMATION: "PAY-EST",
    PURCHASE_INVENTORY: "PAY-PUR",
    ACCOUNTS_BILLING: "PAY-ACC",
    ENGINEERING_TECHNICAL: "PAY-ENG",
    CLIENT: "PAY-CLI"
  }[department] || "PAY-USR";

  const row = db.prepare(
    "SELECT COUNT(*) AS n FROM users WHERE department = ?"
  ).get(department);

  return `${prefix}-${String(row.n + 1).padStart(3, "0")}`;
}

function randomPassword() {
  return crypto.randomBytes(6).toString("base64url") + "A1!";
}

app.get("/api/health", (_, res) => res.json({ ok: true, service: "PayPal ERP API" }));

app.post("/api/auth/login", (req, res) => {
  const { loginId, password } = req.body;
  if (!loginId || !password) return res.status(400).json({ message: "Login ID and password are required" });

  const user = db.prepare(
    "SELECT * FROM users WHERE login_id = ? AND status = 'ACTIVE'"
  ).get(loginId.trim());

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ message: "Invalid login ID or password" });
  }

  res.json({
    token: signUser(user),
    user: {
      id: user.id,
      loginId: user.login_id,
      name: user.name,
      email: user.email,
      department: user.department,
      role: user.role,
      status: user.status
    }
  });
});

app.post("/api/client/register", (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: "Name, email and password are required" });
  if (password.length < 8) return res.status(400).json({ message: "Password must be at least 8 characters" });

  try {
    const loginId = makeLoginId("CLIENT");
    const hash = bcrypt.hashSync(password, 12);
    const result = db.prepare(`
      INSERT INTO users (login_id,email,password_hash,name,department,role)
      VALUES (?,?,?,?,?,?)
    `).run(loginId, email.trim().toLowerCase(), hash, name.trim(), "CLIENT", "CLIENT");

    res.status(201).json({
      message: "Client account created",
      loginId,
      userId: result.lastInsertRowid
    });
  } catch {
    res.status(409).json({ message: "Email already exists" });
  }
});

app.get("/api/me", auth, (req, res) => res.json({ user: req.user }));

app.get("/api/users", auth, allow("OWNER"), (_, res) => {
  const rows = db.prepare(`
    SELECT id,login_id,email,name,department,role,status,created_at
    FROM users ORDER BY id DESC
  `).all();
  res.json(rows);
});

app.post("/api/users", auth, allow("OWNER"), (req, res) => {
  const { name, email, department, role } = req.body;
  if (!name || !department || !role) {
    return res.status(400).json({ message: "Name, department and role are required" });
  }
  if (!departments.includes(department) || !roles.includes(role)) {
    return res.status(400).json({ message: "Invalid department or role" });
  }
  if (department === "CLIENT") {
    return res.status(400).json({ message: "Use client registration for client accounts" });
  }

  const loginId = makeLoginId(department);
  const tempPassword = randomPassword();
  const hash = bcrypt.hashSync(tempPassword, 12);

  try {
    const result = db.prepare(`
      INSERT INTO users (login_id,email,password_hash,name,department,role)
      VALUES (?,?,?,?,?,?)
    `).run(loginId, email || null, hash, name.trim(), department, role);

    res.status(201).json({
      message: "User created after owner authentication",
      userId: result.lastInsertRowid,
      loginId,
      temporaryPassword: tempPassword
    });
  } catch (e) {
    res.status(409).json({ message: "Could not create user. Email may already exist." });
  }
});

app.patch("/api/users/:id/status", auth, allow("OWNER"), (req, res) => {
  const status = req.body.status;
  if (!["ACTIVE", "INACTIVE"].includes(status)) return res.status(400).json({ message: "Invalid status" });
  db.prepare("UPDATE users SET status = ? WHERE id = ?").run(status, req.params.id);
  res.json({ message: "User status updated" });
});

app.post("/api/projects/setup", auth, allow("CLIENT"), (req, res) => {
  const { projectName, description, location } = req.body;
  if (!projectName) return res.status(400).json({ message: "Project name is required" });

  const code = `PAY-PRJ-${Date.now().toString().slice(-7)}`;
  const result = db.prepare(`
    INSERT INTO projects (project_code,client_user_id,project_name,description,location)
    VALUES (?,?,?,?,?)
  `).run(code, req.user.id, projectName, description || "", location || "");

  res.status(201).json({
    message: "Project setup submitted to Sales & Marketing and Admin/Management",
    projectId: result.lastInsertRowid,
    projectCode: code
  });
});

app.get("/api/projects", auth, (req, res) => {
  let rows;
  if (req.user.role === "CLIENT") {
    rows = db.prepare(`
      SELECT p.*, u.name AS client_name
      FROM projects p JOIN users u ON u.id=p.client_user_id
      WHERE p.client_user_id=?
      ORDER BY p.id DESC
    `).all(req.user.id);
  } else {
    rows = db.prepare(`
      SELECT p.*, u.name AS client_name
      FROM projects p LEFT JOIN users u ON u.id=p.client_user_id
      ORDER BY p.id DESC
    `).all();
  }
  res.json(rows);
});

app.get("/api/installations", auth, allow("OWNER","ENGINEER"), (req, res) => {
  const rows = db.prepare(`
    SELECT i.*, p.project_code,p.project_name,u.name AS engineer_name
    FROM installations i
    JOIN projects p ON p.id=i.project_id
    LEFT JOIN users u ON u.id=i.assigned_user_id
    ORDER BY i.id DESC
  `).all();

  if (req.user.role === "ENGINEER") {
    return res.json(rows.filter(x => x.assigned_user_id === req.user.id));
  }
  res.json(rows);
});

app.post("/api/installations", auth, allow("OWNER","ENGINEER"), (req, res) => {
  const {
    projectId,title,siteContact,contactNumber,location,
    startDate,expectedCompletionDate,assignedUserId,notes
  } = req.body;

  if (!projectId || !title) return res.status(400).json({ message: "Project and installation title are required" });

  const code = `PAY-INS-${Date.now().toString().slice(-7)}`;
  const assigned = assignedUserId || req.user.id;

  const result = db.prepare(`
    INSERT INTO installations
    (installation_code,project_id,title,site_contact,contact_number,location,
     start_date,expected_completion_date,assigned_user_id,notes)
    VALUES (?,?,?,?,?,?,?,?,?,?)
  `).run(
    code, projectId, title, siteContact || "", contactNumber || "",
    location || "", startDate || "", expectedCompletionDate || "",
    assigned, notes || ""
  );

  res.status(201).json({ message: "Installation created", installationId: result.lastInsertRowid, installationCode: code });
});

app.patch("/api/installations/:id", auth, allow("OWNER","ENGINEER"), (req, res) => {
  const allowed = [
    "status","actualCompletionDate","notes",
    "startDate","expectedCompletionDate"
  ];
  const fields = [];
  const values = [];
  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      const dbKey = {
        actualCompletionDate:"actual_completion_date",
        startDate:"start_date",
        expectedCompletionDate:"expected_completion_date"
      }[key] || key;
      fields.push(`${dbKey} = ?`);
      values.push(req.body[key]);
    }
  }
  if (!fields.length) return res.status(400).json({ message: "No fields to update" });

  values.push(req.params.id);
  db.prepare(`UPDATE installations SET ${fields.join(", ")} WHERE id = ?`).run(...values);
  res.json({ message: "Installation updated" });
});

app.post("/api/installations/:id/tasks", auth, allow("OWNER","ENGINEER"), (req, res) => {
  const { taskName, description, startDate, targetDate, remarks } = req.body;
  if (!taskName) return res.status(400).json({ message: "Task name is required" });

  const result = db.prepare(`
    INSERT INTO installation_tasks
    (installation_id,task_name,description,start_date,target_date,remarks)
    VALUES (?,?,?,?,?,?)
  `).run(
    req.params.id,taskName,description || "",
    startDate || "",targetDate || "",remarks || ""
  );

  res.status(201).json({ message: "Installation task added", taskId: result.lastInsertRowid });
});

app.get("/api/installations/:id/tasks", auth, allow("OWNER","ENGINEER"), (req, res) => {
  res.json(db.prepare(
    "SELECT * FROM installation_tasks WHERE installation_id=? ORDER BY id DESC"
  ).all(req.params.id));
});

app.patch("/api/installation-tasks/:id", auth, allow("OWNER","ENGINEER"), (req, res) => {
  const { status, remarks, completionDate } = req.body;
  db.prepare(`
    UPDATE installation_tasks
    SET status=COALESCE(?,status),
        remarks=COALESCE(?,remarks),
        completion_date=COALESCE(?,completion_date)
    WHERE id=?
  `).run(status ?? null, remarks ?? null, completionDate ?? null, req.params.id);
  res.json({ message: "Task updated" });
});

app.post("/api/installations/:id/photos", auth, allow("OWNER","ENGINEER"), upload.array("photos", 10), (req, res) => {
  if (!req.files?.length) return res.status(400).json({ message: "No photos uploaded" });

  const insert = db.prepare(`
    INSERT INTO site_photos (installation_id,filename,original_name)
    VALUES (?,?,?)
  `);
  const transaction = db.transaction(files => {
    for (const f of files) insert.run(req.params.id, f.filename, f.originalname);
  });
  transaction(req.files);

  res.status(201).json({
    message: "Site photos uploaded",
    files: req.files.map(f => ({
      originalName: f.originalname,
      url: `/uploads/${f.filename}`
    }))
  });
});

app.get("/api/installations/:id/photos", auth, allow("OWNER","ENGINEER"), (req, res) => {
  const rows = db.prepare(
    "SELECT * FROM site_photos WHERE installation_id=? ORDER BY id DESC"
  ).all(req.params.id);
  res.json(rows.map(x => ({ ...x, url: `/uploads/${x.filename}` })));
});

app.listen(PORT, () => {
  console.log(`PayPal ERP API running on http://localhost:${PORT}`);
});
