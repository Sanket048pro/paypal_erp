# PAYPAL ERP — Web + Android APK Starter

This project is a working starter architecture for the PayPal ERP requirements.

## What is included

- One Node.js/Express backend
- SQLite database for easy local development
- JWT login
- Owner-created user accounts
- Role/department based dashboards
- Web React frontend
- Expo React Native Android app
- Client registration/login
- Client project setup submission
- Engineering & Technical installation records
- Installation tasks, status, site notes and photo upload
- Shared project data through the same API/database

## Important

The BOQ Excel columns are intentionally NOT fixed. Add the exact BOQ Excel format after you provide it.

## Requirements

Install:
- Node.js 20+
- npm
- Android Studio (only if you want a local Android emulator/build)
- Expo Go on an Android phone for quick APK/app testing

## 1. Start backend

```bash
cd backend
npm install
npm run dev
```

Backend:
http://localhost:4000

Health check:
http://localhost:4000/api/health

The first startup creates the SQLite database and an owner account:

Email: owner@paypal-erp.local
Password: Owner@12345

Change this password immediately for real use.

## 2. Start web

Open another terminal:

```bash
cd web
npm install
npm run dev
```

Open the URL shown by Vite, normally:
http://localhost:5173

For a physical Android phone, the backend URL in the app must be your computer's LAN IP, e.g.
http://192.168.1.10:4000

Do NOT use localhost from a physical phone.

## 3. Start Android app

```bash
cd mobile
npm install
npx expo start
```

Then:
- scan the QR code using Expo Go, or
- press `a` with an Android emulator running.

Change `API_URL` in `mobile/src/api.js` to your computer's LAN IP for a physical phone.

## Default owner flow

1. Login as owner.
2. Create an employee.
3. Select department and role.
4. System creates a login ID and temporary password.
5. Employee logs in.
6. Employee sees only the dashboard permitted by their role.

## Current departments

- Owner / Admin
- Client
- Sales & Marketing
- Project Design
- Estimation
- Purchase & Inventory
- Accounts & Billing
- Engineering & Technical

## Installation workflow

Engineering users can:
- view assigned installations
- create installation records
- add tasks
- update status
- add site notes
- upload site photos

The client can see project progress from the shared project record.

## Production warning

This starter is intended for development/prototyping. Before public deployment, add HTTPS, production secrets, database backups, cloud object storage for photos, rate limiting, audit logs, stronger validation, password reset/email delivery, and a production database such as PostgreSQL.
