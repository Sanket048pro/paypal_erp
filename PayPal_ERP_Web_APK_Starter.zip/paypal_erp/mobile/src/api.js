import { Platform } from "react-native";

/*
For a physical Android phone:
replace localhost with your computer's LAN IP:
http://192.168.1.10:4000/api

For Android emulator, http://10.0.2.2:4000/api normally points to
your computer's localhost.
*/
export const API_URL = Platform.OS === "android"
  ? "http://10.0.2.2:4000/api"
  : "http://localhost:4000/api";

export async function api(path, options = {}, token = null) {
  const headers = {...(options.headers || {})};
  if (!(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(API_URL + path, {...options, headers});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}
